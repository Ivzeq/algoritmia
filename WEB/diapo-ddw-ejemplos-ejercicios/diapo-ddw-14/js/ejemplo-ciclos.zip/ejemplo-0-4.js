'use strict';

//let resultado = 'Los numeros ingresados son:';
//let numero    = 0;

/*for (let i=0; i<5; i++) {
	numero = parseInt(prompt('Ingrese un valor numérico.'));
	resultado += numero+ ' ';
}*/

// Un for con while
/*let cont = 0;
while(cont<5) {
	numero = parseInt(prompt('Ingrese un valor numérico.'));
	resultado += numero+ ' ';
	cont++;
}

document.write(`<p><strong>${resultado}</strong></p>`);*/
