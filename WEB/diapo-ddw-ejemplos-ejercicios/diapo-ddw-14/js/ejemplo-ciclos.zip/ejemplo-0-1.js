'use strict';
/*
let resultado = 'Los numeros ingresados son:';
let numero;

while (numero!=0) {
	//Se va a ejecutar mientras la condicion sea true (numero!=0)
	numero = parseInt(prompt('Ingrese un valor numérico.'));
	resultado += numero+ ' ';
}

document.write(`<p><strong>${resultado}</strong></p>`);

*/