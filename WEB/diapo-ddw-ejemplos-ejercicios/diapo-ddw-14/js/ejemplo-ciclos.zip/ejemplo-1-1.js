'use strict';

//Ingresar 5 números. Informar si cada número par o impar.

//Hacerlo con for con incremento empezando desde 1.

let resultado = '';
let numero    = 0;

for (let i=1;i<=5;i++) {
	numero = parseInt(prompt('Ingrese un valor numérico.'));
	resultado +=`<br> El numero: ${numero} es `;
	if (numero%2==0) {
		resultado += `par`;
	} else {
		resultado += `impar`;
	}
}

document.write(`<p><strong>${resultado}</strong></p>`);
