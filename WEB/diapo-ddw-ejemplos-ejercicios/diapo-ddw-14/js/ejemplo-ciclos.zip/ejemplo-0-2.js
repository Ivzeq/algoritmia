'use strict';

let resultado = 'Los numeros que quizo ingresar el usuario son:';
let numero    = 0;

do {
	numero = parseInt(prompt('Ingrese un valor numérico.'));
	resultado += numero+ ' ';
} while (confirm('¿Desea seguir cargando valores?'))

document.write(`<p><strong>${resultado}</strong></p>`);
